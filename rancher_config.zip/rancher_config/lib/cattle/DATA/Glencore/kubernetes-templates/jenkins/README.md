# Jenkins for Glencore

This will run a Jenkins server instance

## URL Path

https://PublicDNSName:8080
