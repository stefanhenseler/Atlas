# Nagios for Glencore

This will run a Nagios server instance

## URL Path

https://PublicDNSName/nagios

## Default Credentials

Username: nagiosadmin
Password: admin
