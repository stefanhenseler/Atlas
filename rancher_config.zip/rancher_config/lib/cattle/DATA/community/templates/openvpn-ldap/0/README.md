# OpenVPN

OpenVPN stack made to give access to Rancher network with LDAP authentication.

OpenVPN version: 1.0-0