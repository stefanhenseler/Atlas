# Minecraft

This will run a standard [Minecraft](https://minecraft.net/) server.

## Configuration

This chart requires no configuration to use.

## Scaling

This server should not be scaled past a single instance.

If you scale past a single instance you will be load balanced across several 
different worlds. You will not be able to select which world you wish to play on.

## Minecraft EULA

By using this chart you implicitly agree to the Minecraft EULA.
