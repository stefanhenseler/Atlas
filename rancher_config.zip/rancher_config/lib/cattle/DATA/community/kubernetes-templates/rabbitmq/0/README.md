# RabbitMQ

This Chart provides a basic RabbitMQ instance running in kubernetes.
